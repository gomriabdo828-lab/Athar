import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

const gold = Color(0xFFB0833A), deep = Color(0xFF2F4A3F), paper = Color(0xFFF6F0E4), cardC = Color(0xFFFFFAF0), ink = Color(0xFF2A2118), mut = Color(0xFF7A6C58);
const topics = [
  ['الطفولة', 'ما أول ذكرى تعود إلى بالك حين تفكر في طفولتك؟ قد تكون رائحة أو صوتاً أو مكاناً أو وجهاً عزيزاً.'],
  ['الأسرة', 'من أكثر شخص في أسرتك أثّر فيك، وما الموقف الذي يجعلك تذكره دائماً؟'],
  ['العمل', 'احكِ لي عن أول يوم عمل لك: كيف كان شعورك وماذا تتذكر منه؟'],
  ['الهجرة والسفر', 'حين غادرتَ مكاناً عزيزاً لأول مرة، ما أول شيء أخذته معك أو التفتّ إليه؟'],
  ['التحديات', 'ما أصعب مرحلة مررتَ بها، ومن وقف إلى جانبك فيها؟'],
  ['الأفراح', 'ما اللحظة التي شعرتَ فيها أن قلبك امتلأ فرحاً؟'],
];
const sys = 'أنت "الموجّه الذكي" في تطبيق «أثر» لتوثيق قصص الحياة. دافئ وصبور ومحترم ثقافياً، وأسلوبك يريح كبار السن. لا تستعجل ولا تقلّل من شأن أي شعور. اكتب بعربية فصيحة سلسة. حافظ على صوت المستخدم ومشاعره الأصلية ونظّف الحشو فقط. أجب بـ JSON فقط بلا أي نص آخر ولا علامات ماركداون وفق الشكل: {"empathy":"جملة واحدة قصيرة تعكس القصة","memory":null أو {"title":"عنوان جذاب","era":"الفترة أو المرحلة العمرية التقريبية","narrative":"القصة مصاغة بأسلوب سلس وأنيق بصيغة المتكلم","lesson":"الدرس أو الأثر","tags":["أسرة","طفولة"]},"question":"سؤال واحد مركّز ومؤثر مرتبط بتفصيل ذكره المستخدم في آخر رد"}. ضع memory فقط إذا روى المستخدم قصة فعلية.';

void main() => runApp(const AtharApp());

class AtharApp extends StatelessWidget {
  const AtharApp({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'أثر',
        theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: gold), scaffoldBackgroundColor: paper),
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _S();
}

class _S extends State<Shell> {
  int idx = 0;
  List<Map<String, dynamic>> mems = [], chat = [];
  String key = '';
  bool busy = false, rec = false;
  SharedPreferences? p;
  final ctl = TextEditingController(), sc = ScrollController(), sp = stt.SpeechToText();

  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    p = await SharedPreferences.getInstance();
    setState(() {
      key = p!.getString('key') ?? '';
      mems = (jsonDecode(p!.getString('mems') ?? '[]') as List).map((e) => Map<String, dynamic>.from(e)).toList();
    });
  }

  void persist() => p?.setString('mems', jsonEncode(mems));
  void toast(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  void start(String q) => setState(() {
        chat = [{'r': 'ai', 'e': 'أهلاً بك في «أثر» 🌿 احكِ كما تحكي لأقرب الناس إليك.', 'q': q}];
        idx = 1;
      });
  void down() => Future.delayed(const Duration(milliseconds: 150), () {
        if (sc.hasClients) sc.animateTo(sc.position.maxScrollExtent, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      });

  Future<void> settings() async {
    final t = TextEditingController(text: key);
    await showDialog(
        context: context,
        builder: (c) => AlertDialog(
              title: const Text('مفتاح Anthropic API'),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                const Text('يُحفظ على هاتفك فقط، ويُستخدم لتشغيل الموجّه الذكي.', style: TextStyle(fontSize: 13, color: mut)),
                const SizedBox(height: 10),
                TextField(controller: t, obscureText: true, textDirection: TextDirection.ltr, decoration: const InputDecoration(hintText: 'sk-ant-...', border: OutlineInputBorder())),
              ]),
              actions: [
                TextButton(
                    onPressed: () {
                      setState(() => key = t.text.trim());
                      p?.setString('key', key);
                      Navigator.pop(c);
                    },
                    child: const Text('حفظ'))
              ],
            ));
  }

  Future<void> send() async {
    final t = ctl.text.trim();
    if (t.isEmpty || busy) return;
    if (key.isEmpty) {
      toast('أضف مفتاح API أولاً من أيقونة الإعدادات');
      return settings();
    }
    ctl.clear();
    setState(() {
      chat.add({'r': 'user', 't': t});
      busy = true;
    });
    down();
    try {
      final h = chat.length > 10 ? chat.sublist(chat.length - 10) : chat;
      final hs = h.map((m) => m['r'] == 'user' ? 'المستخدم: ${m['t']}' : 'الموجّه: ${m['q']}').join('\n');
      final res = await http.post(Uri.parse('https://api.anthropic.com/v1/messages'),
          headers: {'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json'},
          body: jsonEncode({'model': 'claude-sonnet-5-5', 'max_tokens': 1200, 'messages': [{'role': 'user', 'content': '$sys\n\nسجل المحادثة:\n$hs'}]}));
      if (res.statusCode != 200) throw 'خطأ ${res.statusCode}: تحقق من المفتاح';
      final d = jsonDecode(utf8.decode(res.bodyBytes));
      final s = (d['content'][0]['text'] as String).replaceAll(RegExp(r'```json|```'), '').trim();
      final r = jsonDecode(s) as Map<String, dynamic>;
      setState(() => chat.add({'r': 'ai', 'e': r['empathy'], 'm': r['memory'], 'q': r['question']}));
    } catch (e) {
      toast('تعذّر الاتصال: $e');
    }
    setState(() => busy = false);
    down();
  }

  Future<void> mic() async {
    if (rec) {
      await sp.stop();
      return setState(() => rec = false);
    }
    if (!await sp.initialize()) return toast('التسجيل الصوتي غير متاح');
    setState(() => rec = true);
    final base = ctl.text;
    sp.listen(localeId: 'ar_SA', onResult: (r) {
      ctl.text = '$base ${r.recognizedWords}'.trim();
      if (r.finalResult) setState(() => rec = false);
    });
  }

  Widget memo(Map m, {VoidCallback? onSave, VoidCallback? onDel}) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: cardC, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE4D7BD)), boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 14, offset: Offset(0, 4))]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${m['era']}', style: const TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 13)),
          Text('${m['title']}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: ink)),
          const SizedBox(height: 6),
          Text('${m['narrative']}', style: const TextStyle(fontSize: 16, height: 1.8, color: ink)),
          const SizedBox(height: 6),
          Text('✦ ${m['lesson']}', style: const TextStyle(color: deep, fontSize: 14)),
          const SizedBox(height: 8),
          Wrap(spacing: 6, children: [for (final t in (m['tags'] ?? []) as List) Chip(label: Text('$t', style: const TextStyle(fontSize: 12)), visualDensity: VisualDensity.compact, backgroundColor: const Color(0x1F2F4A3F), side: BorderSide.none)]),
          if (onSave != null) FilledButton(style: FilledButton.styleFrom(backgroundColor: gold), onPressed: onSave, child: const Text('حفظ في أثر ✓')),
          if (onDel != null) Align(alignment: AlignmentDirectional.centerEnd, child: TextButton(onPressed: onDel, child: const Text('حذف', style: TextStyle(color: mut)))),
        ]),
      );

  Widget home() => ListView(padding: const EdgeInsets.all(18), children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [deep, Color(0xFF1D2F28)]), borderRadius: BorderRadius.circular(24)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('اترك أثراً يُحكى بعدك', style: TextStyle(color: Color(0xFFF6ECD6), fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('تحدّث أو اكتب كما تحب، ونحن نحوّل ذكرياتك إلى سيرة مرتبة تحفظها الأجيال.', style: TextStyle(color: Color(0xCCF6ECD6))),
            const SizedBox(height: 14),
            FilledButton(style: FilledButton.styleFrom(backgroundColor: const Color(0xFFD9B26A), foregroundColor: ink), onPressed: () => start(topics[0][1]), child: const Text('ابدأ الحكاية ✦')),
          ]),
        ),
        const SizedBox(height: 16),
        Row(children: [
          for (final s in [['ذكرى', mems.length], ['مرحلة', mems.map((e) => e['era']).toSet().length], ['وسم', mems.expand((e) => (e['tags'] ?? []) as List).toSet().length]])
            Expanded(child: Card(color: cardC, elevation: 0, child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Text('${s[1]}', style: const TextStyle(fontSize: 26, color: gold, fontWeight: FontWeight.bold)), Text('${s[0]}', style: const TextStyle(fontSize: 12, color: mut))])))),
        ]),
        const SizedBox(height: 10),
        const Text('من أين تريد أن تبدأ؟', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 4, children: [for (final t in topics) ActionChip(backgroundColor: cardC, label: Text(t[0]), onPressed: () => start(t[1]))]),
        const SizedBox(height: 16),
        if (mems.isNotEmpty) ...[const Text('آخر ما حفظتَ', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), const SizedBox(height: 10), memo(mems.last)],
      ]);

  Widget talk() => Column(children: [
        Expanded(
            child: ListView(controller: sc, padding: const EdgeInsets.all(16), children: [
          for (var i = 0; i < chat.length; i++) bubble(chat[i]),
          if (busy) const Padding(padding: EdgeInsets.all(12), child: Align(alignment: AlignmentDirectional.centerStart, child: CircularProgressIndicator(strokeWidth: 2, color: gold))),
        ])),
        Container(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
          decoration: const BoxDecoration(border: Border(top: BorderSide(color: Color(0xFFE4D7BD)))),
          child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            IconButton.outlined(onPressed: mic, icon: Icon(rec ? Icons.stop : Icons.mic, color: rec ? Colors.red : gold)),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: ctl, minLines: 1, maxLines: 4, decoration: InputDecoration(hintText: 'احكِ ذكراك هنا…', filled: true, fillColor: cardC, border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none)))),
            const SizedBox(width: 8),
            IconButton.filled(style: IconButton.styleFrom(backgroundColor: gold), onPressed: send, icon: const Icon(Icons.send)),
          ]),
        ),
      ]);

  Widget bubble(Map<String, dynamic> m) {
    if (m['r'] == 'user') {
      return Align(alignment: AlignmentDirectional.centerEnd, child: Container(margin: const EdgeInsets.only(bottom: 12, right: 40), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: deep, borderRadius: BorderRadius.circular(20)), child: Text('${m['t']}', style: const TextStyle(color: Color(0xFFF6ECD6), fontSize: 16))));
    }
    final mm = m['m'] == null ? null : Map<String, dynamic>.from(m['m']);
    return Align(
        alignment: AlignmentDirectional.centerStart,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12, left: 20),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: cardC, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE4D7BD))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${m['e']}', style: const TextStyle(color: mut, fontSize: 14)),
            if (mm != null) ...[
              const SizedBox(height: 8),
              memo(mm, onSave: m['saved'] == true ? null : () {
                setState(() {
                  mems.add({...mm, 'id': DateTime.now().millisecondsSinceEpoch});
                  m['saved'] = true;
                });
                persist();
                toast('حُفظت الذكرى في خطك الزمني');
              }),
            ],
            const SizedBox(height: 8),
            Text('${m['q']}', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: gold, height: 1.6)),
          ]),
        ));
  }

  Widget timeline() => mems.isEmpty
      ? const Center(child: Text('🌱\nلم تُحفظ أي ذكرى بعد.\nابدأ المقابلة وستظهر حكاياتك هنا.', textAlign: TextAlign.center, style: TextStyle(color: mut, fontSize: 16, height: 1.8)))
      : ListView(padding: const EdgeInsets.all(18), children: [
          for (final m in mems)
            memo(m, onDel: () {
              setState(() => mems.remove(m));
              persist();
            })
        ]);

  String get json => const JsonEncoder.withIndent('  ').convert({'app': 'athar', 'version': 1, 'exported_at': DateTime.now().toIso8601String(), 'memories': mems});

  Widget export() => ListView(padding: const EdgeInsets.all(18), children: [
        const Text('تصدير البيانات', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const Text('ملف JSON نظيف جاهز لتطبيقات Flutter و React Native.', style: TextStyle(color: mut)),
        const SizedBox(height: 10),
        FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: gold), onPressed: () {
          Clipboard.setData(ClipboardData(text: json));
          toast('نُسخ JSON');
        }, icon: const Icon(Icons.copy), label: const Text('نسخ')),
        const SizedBox(height: 10),
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFF1B1812), borderRadius: BorderRadius.circular(16)), child: Directionality(textDirection: TextDirection.ltr, child: SelectableText(json, style: const TextStyle(color: Color(0xFFE8D9B5), fontSize: 12, fontFamily: 'monospace')))),
      ]);

  @override
  Widget build(BuildContext c) {
    final pages = [home(), talk(), timeline(), export()];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: paper,
        title: const Text('أثر', style: TextStyle(color: gold, fontSize: 30, fontWeight: FontWeight.bold)),
        actions: [IconButton(onPressed: settings, icon: const Icon(Icons.settings_outlined, color: mut))],
      ),
      body: SafeArea(child: pages[idx]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: cardC,
        selectedIndex: idx,
        onDestinationSelected: (i) {
          if (i == 1 && chat.isEmpty) return start(topics[0][1]);
          setState(() => idx = i);
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.mic_none), label: 'المقابلة'),
          NavigationDestination(icon: Icon(Icons.timeline), label: 'الخط الزمني'),
          NavigationDestination(icon: Icon(Icons.ios_share), label: 'تصدير'),
        ],
      ),
    );
  }
}
